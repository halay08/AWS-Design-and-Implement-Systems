
// test to make sure node.js is setup correctly - install node and install npm

var msg = 'Hello World';
console.log(msg);

// aws.amazon.com/tools
// npm install aws-sdk
// NOTE: You may have to run 'npm install' 
// from this directory to get all needed node modules
// NOTE2: Create credential file only 
// if not already there (from previous awscli movies)