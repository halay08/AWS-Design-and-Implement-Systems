#!/bin/bash

#   INSTALL -- aws.amazon.com/cli
#   VERIFY or SETUP AWS Credentials
#       ~/.aws/credentials on Linux, macOS, or Unix
#       C:\Users\USERNAME \.aws\credentials on Windows

# Best practice, verify version of awscli
aws --version

# Best practice, verify user configuration
aws configure

# Lists all buckets
aws s3 ls

# Lists contents of named bucket
aws s3 ls s3://demo-simple-lynn-data

# Create a new bucket in a particular region
aws s3 mb s3://demo-simple-lynn-new-today --region us-west-1

# Lists all buckets
aws s3 ls
